COLORS = ['#69D2E7', '#1B676B', '#BEF202', '#EBE54D', '#00CDAC', '#1693A5', '#F9D423', '#FF4E50', '#E7204E', '#0CCABA', '#FF006F'];

// Particle
Particle = class Particle {
  constructor(x1 = 0, y1 = 0) {
    this.x = x1;
    this.y = y1;
    this.reset();
  }

  reset() {
    this.level = 1 + floor(random(4));
    this.scale = random(10, 50);
    this.alpha = random(0.2, 0.8);
    this.speed = random(1, 3);
    this.color = random(COLORS);
    this.size = random(2, 8);
    this.spin = random(-0.02, 0.02);
    this.smoothedScale = 0.0;
    this.smoothedAlpha = 0.0;
    this.decayScale = 0.0;
    this.decayAlpha = 0.0;
    this.rotation = random(TWO_PI);
    return this.energy = 0.0;
  }

  move() {
    this.rotation += this.spin;
    this.rotation %= TWO_PI;
    this.y -= this.speed * this.level;
  }

  draw(ctx) {
    const power = exp(this.energy);
    const scale = this.scale * power;
    const alpha = this.alpha * this.energy * 1.5;
    this.decayScale = max(this.decayScale, scale);
    this.decayAlpha = max(this.decayAlpha, alpha);
    this.smoothedScale += (this.decayScale - this.smoothedScale) * 0.3;
    this.smoothedAlpha += (this.decayAlpha - this.smoothedAlpha) * 0.3;
    this.decayScale *= 0.985;
    this.decayAlpha *= 0.975;
    ctx.save();
    ctx.beginPath();
    ctx.translate(this.x + cos(this.rotation * this.speed) * 250, this.y);
    ctx.rotate(this.rotation);
    ctx.scale(this.smoothedScale * this.level, this.smoothedScale * this.level);
    ctx.moveTo(this.size * 0.5, 0);
    ctx.lineTo(this.size * -0.5, 0);
    ctx.lineWidth = 1;
    ctx.lineCap = 'round';
    ctx.globalAlpha = this.smoothedAlpha / this.level;
    ctx.strokeStyle = this.color;
    ctx.stroke();
    ctx.restore();
  }
};

// Sketch
Sketch.create({
  particles: [],
  setup: function () {
    for (let i = 0; i < 50; i++) {
      const x = random(this.width);
      const y = random(this.height * 2);
      const particle = new Particle(x, y);
      particle.energy = random();
      this.particles.push(particle);
    }
  },
  draw: function () {
    this.globalCompositeOperation = 'lighter';
    for (const particle of this.particles) {
      if (particle.y < -particle.size * particle.level * particle.scale * 2) {
        particle.reset();
        particle.x = random(this.width);
        particle.y = this.height + particle.size * particle.scale * particle.level;
      }
      particle.move();
      particle.draw(this);
      
    }
  },
  loop: true, // Enable looping
});
